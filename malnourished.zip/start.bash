#!/bin/bash
npm i && npm start