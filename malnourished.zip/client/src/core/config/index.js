export const config = {
  ENV: "dev",
  title: "Nutrition Los Banos",
  host: "http://localhost:5000",
  headers: {
    Accept: "application/json",
    "Content-Type": "application/json"
  }
};
