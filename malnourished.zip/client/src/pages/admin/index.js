import React from 'react'
import Content from '../../components/content/Content'

const Index = () => {
    return (
        <Content>
            
        </Content>
    )
}

export default Index
